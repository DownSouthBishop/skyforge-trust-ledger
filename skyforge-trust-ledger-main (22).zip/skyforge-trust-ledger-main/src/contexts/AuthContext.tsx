import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase as _sb } from "@/integrations/supabase/client";
const supabase = _sb as any;
import type { User, Session } from "@supabase/supabase-js";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
};

const OWNER_EMAIL    = import.meta.env.VITE_OWNER_EMAIL as string | undefined;
const OWNER_PASSWORD = import.meta.env.VITE_OWNER_PASSWORD as string | undefined;

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setSession(session);
        setUser(session.user);
        setLoading(false);
      } else if (
        OWNER_EMAIL &&
        OWNER_PASSWORD &&
        localStorage.getItem("explicit_signout") !== "1"
      ) {
        // No stored session AND user hasn't explicitly signed out — auto sign-in silently
        supabase.auth.signInWithPassword({ email: OWNER_EMAIL, password: OWNER_PASSWORD })
          .then(({ data }) => {
            setSession(data.session);
            setUser(data.session?.user ?? null);
          })
          .catch(() => {})
          .finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, fullName: string) => {
    localStorage.removeItem("explicit_signout");
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });
    if (error) throw error;
  };

  const signIn = async (email: string, password: string) => {
    localStorage.removeItem("explicit_signout");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const signOut = async () => {
    localStorage.setItem("explicit_signout", "1");
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};
